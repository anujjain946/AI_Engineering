def main():
    print("Hello from genai-introduction-9aug-4pm!")


if __name__ == "__main__":
    main()
